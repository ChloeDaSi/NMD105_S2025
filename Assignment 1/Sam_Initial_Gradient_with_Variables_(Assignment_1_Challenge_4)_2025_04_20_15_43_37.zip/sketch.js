function setup() {
  fill("white");
  createCanvas(400, 400);
}

function draw() {
  background(220);
  stroke("white");

  let currentLightness = 20; 
  const lightnessIncrement = 15; 

  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      let isGray = 
        (row === 0 && col !== 0 && col !== 4) || 
        (row === 1 && col === 1) || 
        (row === 2 && col !== 0 && col !== 4) || 
        (row === 3 && col === 3) || 
        (row === 4 && col !== 0 && col !== 4); 

      const hslColor = `hsl(130, 50%, ${currentLightness}%)`;

      if (isGray) {
        fill("slategray");
      } else {
        fill(hslColor);
      }

      rect(col * 80, row * 80, 80, 80);
    }

    currentLightness += lightnessIncrement;
  }
}
