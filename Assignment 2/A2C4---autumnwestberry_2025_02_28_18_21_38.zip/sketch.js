function setup() {
  createCanvas(600, 400);
  angleMode(DEGREES);
}

function draw() {
  background(220);
  noStroke();

  //interior
  fill("white");
  addRect(0, 0);
  fill("gold");
  addSun(60, 30);
  fill("green");
  addRect(0, 150);

  //triangles
  fill("red");
  triangle(0, 0, 0, 400, 300, 400);
  triangle(600, 0, 600, 400, 300, 400);
}

function addRect(x, y) {
  push();
  translate(x, y);

  rect(0, 0, 600, 300);
  pop();
}

function addSun(x, y) {
  push();
  translate(x, y);

  ellipse(40, 110, 90, 90);

  triangle(20, 0, 0, 90, 40, 90);

  push();
  rotate(20);
  translate(50, -20);
  triangle(20, 0, 0, 90, 40, 90);
  pop();

  push();
  rotate(50);
  translate(80, -75);
  triangle(20, 0, 0, 90, 40, 90);
  pop();

  push();
  rotate(75);
  translate(90, -120);
  triangle(20, 0, 0, 90, 40, 90);
  pop();

  push();
  rotate(90);
  translate(100, -150);
  triangle(20, 0, 0, 90, 40, 90);
  pop();

  pop();
}
