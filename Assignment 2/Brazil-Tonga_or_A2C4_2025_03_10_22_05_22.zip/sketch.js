function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(127, 153, 189);
  fill(199, 212, 115)
  ellipse(300, 200, 200)
    fill(71, 107, 65);
  tongaPlus();
  brazil(350, 0);
  brazil(-350, 0);
  brazil(-150, 200);
  brazil(150, 200);
  brazil(-150, -200);
  brazil(150, -200);

  star(0, 50, 0.2);
  star(70, 100, 0.2);
  star(515, 50, 0.2);
  star(445, 100, 0.2);
  star(0, 265, 0.2);
  star(70, 215, 0.2);
  star(515, 265, 0.2);
  star(445, 215, 0.2);
  fill("white")
  
}

function brazil(x, y, size) {
  push();
  translate(x, y);
  scale(size);
  beginShape();
  vertex(150, 200);
  vertex(300, 100);
  vertex(450, 200);
  vertex(300, 300);
  vertex(150, 200);
  endShape();
  pop();
}

function tongaPlus(x, y, size) {
  push();
  translate(x, y);
  scale(size);
  fill(184, 98, 97)
  beginShape();
  vertex(280, 150);
  vertex(320, 150);
  vertex(320, 180);
  vertex(350, 180);
  vertex(350, 220);
  vertex(320, 220);
  vertex(320, 250);
  vertex(280, 250);
  vertex(280, 220);
  vertex(250, 220);
  vertex(250, 180);
  vertex(280, 180);
  vertex(280, 150);
  endShape();
  pop();
}
function star(x, y, size) {
  push();
  translate(x, y);
  scale(size);
  fill(1, 33, 105);
  beginShape();
  vertex(330, 180);
  vertex(250, 180);
  vertex(220, 95);
  vertex(180, 180);
  vertex(100, 180);
  vertex(165, 235);
  vertex(140, 305);
  vertex(215, 265);
  vertex(290, 305);
  vertex(265, 235);
  endShape();
  pop();
}
