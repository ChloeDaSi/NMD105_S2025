function setup() {
  createCanvas(400, 400); 
  background(220);       
  noFill();               
  stroke(0);              

  beginShape();   
  fill("orchid");
  vertex(200, 120);     
  vertex(170, 100);    
  vertex(140, 120);    
  vertex(140, 160);      
  vertex(200, 240);     
  vertex(260, 160);     
  vertex(260, 120);    
  vertex(230, 100); 
  vertex(200, 120);      
  endShape(CLOSE);        
}
