function setup() {
  createCanvas(400, 400);
  noFill();
  stroke(0);
}

function draw() {
  background(220);
  fill("darkorchid");
  drawHeart(190, 240, 1.5)
  fill("mediumorchid");
  drawHeart(190, 225, 1);
  fill("orchid");
  drawHeart(190, 210, .5)
}

function drawHeart(x, y, scaleFactor) {
  push();   
  translate(200, y);
  scale(scaleFactor);    

  beginShape();          
  vertex(0, -80);        
  vertex(-30, -100);     
  vertex(-60, -80);  
  vertex(-60, -40);  
  vertex(0, 40); 
  vertex(60, -40);
  vertex(60, -80);
  vertex(30, -100);     
  vertex(0, -80);      
  endShape(CLOSE);   

  pop();   
}
