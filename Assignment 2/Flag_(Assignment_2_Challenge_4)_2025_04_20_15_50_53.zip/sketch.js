function setup() {
  createCanvas(600, 400); 
  
  // This is a flag mix between Somalia and Canada. Thank you.
  
  //Somalia blue for background
  background(0, 124, 176); 
  //Canada red for sides
  fill(255, 0, 0);        
  rect(0, 0, 150, 400); 
  rect(450, 0, 150, 400); 
  //White for star
  fill(255);           
  drawStar(100, -30, 1);
}

function drawStar(x, y, scaleFactor) {
  push();
  translate(x, y);
  scale(1);
  
  beginShape();
  vertex(200, 100);
  vertex(240, 200);
  vertex(350, 200);
  vertex(260, 250);
  vertex(300, 350);
  vertex(200, 300);
  vertex(100, 350);
  vertex(140, 250);
  vertex(50, 200);
  vertex(160, 200);
  endShape(CLOSE);
  
  pop();
}