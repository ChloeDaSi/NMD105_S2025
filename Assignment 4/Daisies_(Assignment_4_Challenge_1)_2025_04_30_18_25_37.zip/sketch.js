function setup() {
  createCanvas(600, 600);
  background(200);

  drawDaisy(300, 300, 120, 12, color("whitesmoke"), color("goldenrod"));
  drawDaisy(120, 120, 100, 10, color("whitesmoke"), color("goldenrod"));
  drawDaisy(500, 200, 40, 6, color("whitesmoke"), color("goldenrod"));
  drawDaisy(190, 500, 60, 8, color("whitesmoke"), color("goldenrod"));
}

function drawDaisy(x, y, petalLength, petalCount, centerColor, petalColor) {
  fill("whitesmoke");
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + (cos(i) * petalLength) / 2;
    let petalY = y + (sin(i) * petalLength) / 2;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 3, petalLength);
    pop();
  }

  fill("goldenrod");
  ellipse(x, y, petalLength / 2);
}
