let sprites = ["daisy", "circle", "flower"]; 
let tileSize = 150; 

function setup() {
  createCanvas(1200, 1200);
  background(220);

  let cols = width / tileSize;
  let rows = height / tileSize;

  let index = 0; 
  for (let col = 0; col < cols; col++) {
    for (let row = 0; row < rows; row++) {
      let x = col * tileSize + tileSize / 2;
      let y = row * tileSize + tileSize / 2;

      let spriteType = sprites[index % sprites.length]; 
      drawSprite(spriteType, x, y, tileSize);

      index++; 
    }
  }
}

function drawSprite(type, x, y, size) {
  switch (type) {
    case "daisy":
      drawDaisy(x, y, size / 3, 10, color("whitesmoke"), color("goldenrod"));
      break;
    case "circle":
      drawCircle(x, y, size);
      break;
    case "flower":
      drawFlower(x, y, size / 4, 8, color("pink"), color("lightblue"));
      break;
  }
}

function drawDaisy(x, y, petalLength, petalCount, centerColor, petalColor) {
  fill(petalColor);
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 2;
    let petalY = y + sin(i) * petalLength / 2;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 3, petalLength);
    pop();
  }

  fill(centerColor);
  ellipse(x, y, petalLength / 2);
}

function drawCircle(x, y, size) {
  fill(200, 100, 255, 150);
  noStroke();
  ellipse(x, y, size / 2);
}

function drawFlower(x, y, petalLength, petalCount, petalColor, secondaryColor) {
  fill(petalColor);
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 1.5;
    let petalY = y + sin(i) * petalLength / 1.5;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 2, petalLength);
    pop();
  }

  fill(secondaryColor);
  ellipse(x, y, petalLength / 3);
}

