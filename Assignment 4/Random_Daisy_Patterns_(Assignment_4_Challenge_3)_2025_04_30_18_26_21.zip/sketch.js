let tileSize, cols, rows;

function setup() {
  createCanvas(600, 600);
  background(220);

  tileSize = 150;
  cols = width / tileSize;
  rows = height / tileSize;

  noLoop(); 
}

function draw() {
  for (let col = 0; col < cols; col++) {
    for (let row = 0; row < rows; row++) {
      let x = col * tileSize + tileSize / 2;
      let y = row * tileSize + tileSize / 2;
      drawTile(x, y, tileSize);
    }
  }
}

function drawTile(x, y, size) {
  let spriteOptions = ["daisy", "circle", "flower"];
  let chosenSprite = random(spriteOptions); 

  switch (chosenSprite) {
    case "daisy":
      drawDaisy(
        x,
        y,
        random(size / 4, size / 2),
        int(random(6, 12)),
        color(random(200, 255), random(200, 255), random(0, 100)),
        color(random(0, 255), random(0, 255), random(0, 255))
      );
      break;
    case "circle":
      drawRandomCircle(x, y, size);
      break;
    case "flower":
      drawFlower(
        x,
        y,
        random(size / 4, size / 2),
        int(random(4, 10)),
        color(random(200, 255), random(100, 200), random(50, 150)),
        color(random(50, 200), random(50, 200), random(50, 200))
      );
      break;
  }
}

function drawDaisy(x, y, petalLength, petalCount, centerColor, petalColor) {
  fill(petalColor);
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 2;
    let petalY = y + sin(i) * petalLength / 2;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 3, petalLength);
    pop();
  }

  fill(centerColor);
  ellipse(x, y, petalLength / 2);
}

function drawRandomCircle(x, y, size) {
  let radius = random(size / 4, size / 2);
  fill(random(100, 255), random(100, 255), random(100, 255), 150);
  noStroke();
  ellipse(x, y, radius);
}

function drawFlower(x, y, petalLength, petalCount, petalColor, secondaryColor) {
  fill(petalColor);
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 1.5;
    let petalY = y + sin(i) * petalLength / 1.5;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 2.5, petalLength);
    pop();
  }
  
  fill(secondaryColor);
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 3;
    let petalY = y + sin(i) * petalLength / 3;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 3, petalLength / 2);
    pop();
  }

  fill(50, 200, 50);
  ellipse(x, y, petalLength / 3);
}
