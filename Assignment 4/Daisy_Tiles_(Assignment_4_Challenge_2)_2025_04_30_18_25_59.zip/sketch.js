let tileSize;
let cols, rows;

function setup() {
  createCanvas(600, 600);
  background(200);
  
  tileSize = 150;
  cols = width / tileSize;
  rows = height / tileSize;

  noLoop();
}

function draw() {
  for (let col = 0; col < cols; col++) {
    for (let row = 0; row < rows; row++) {
      let x = col * tileSize + tileSize / 2;
      let y = row * tileSize + tileSize / 2;
      drawTile(x, y, tileSize);
    }
  }
}

function drawTile(x, y, size) {
 
  drawDaisy(x, y, size / 3, 12, color("whitesmoke"), color("goldenrod"));
  drawDaisy(x - size / 4, y - size / 4, size / 4, 8, color("whitesmoke"), color("pink"));
  drawDaisy(x + size / 4, y + size / 4, size / 6, 6, color("whitesmoke"), color("lightblue"));
}

function drawDaisy(x, y, petalLength, petalCount, centerColor, petalColor) {
  fill(petalColor)
  noStroke();
  for (let i = 0; i < TWO_PI; i += TWO_PI / petalCount) {
    let petalX = x + cos(i) * petalLength / 2;
    let petalY = y + sin(i) * petalLength / 2;
    push();
    translate(petalX, petalY);
    rotate(i);
    ellipse(0, 0, petalLength / 3, petalLength);
    pop();
  }

  fill(centerColor);
  ellipse(x, y, petalLength / 2);
}
