let groundY = 460;

function setup() {
  createCanvas(400, 400);
  background(255);
}

function draw() {
  background(255);

  // Ground
  fill(150, 100, 50);
  rect(0, 380, 400, 20);

  addCatcher(mouseX, groundY); 
}

function addCatcher(x, y) {
  translate(x - 100, y - 250); 
  scale(0.5);

  fill(150, 100, 50);
  ellipse(140, 250, 150, 200); 
  ellipse(140, 150, 200, 200); 

  // Ears
  fill(100, 50, 0);
  push();
  translate(50, -30);
  rotate(-QUARTER_PI / 5);
  ellipse(150, 170, 60, 100); // Left
  pop();
  push();
  translate(-50, -30);
  rotate(QUARTER_PI / 5);
  ellipse(130, 125, 60, 100); // Right
  pop();

  // Eyes
  fill(255);
  ellipse(110, 130, 50, 30); // Left 
  ellipse(170, 130, 50, 30); // Right 

  fill(0); // Pupils
  ellipse(110, 130, 20, 20); // Left
  ellipse(170, 130, 20, 20); // Right 

  // Nose
  fill(100, 50, 0);
  triangle(140, 160, 130, 190, 150, 190);

  // Paws
  fill(100, 50, 0);
  ellipse(100, 340, 60, 40); // Left
  ellipse(180, 340, 60, 40); // Right 

  if (mouseIsPressed) {
    fill(0); 
    ellipse(140, 220, 40, 20);
  } else {
    noFill(); 
    stroke(0);
    strokeWeight(4);
    beginShape();
    vertex(130, 210);
    vertex(140, 220);
    vertex(150, 210);
    endShape();
  }
  if (mouseIsPressed) {
    fill(150, 100, 50);
    ellipse(110, 130, 50, 30); 
    ellipse(170, 130, 50, 30);
    
  }
}