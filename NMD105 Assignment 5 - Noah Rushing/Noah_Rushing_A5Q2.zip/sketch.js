let bubbles = [];

function setup() {
  createCanvas(960, 540);
  
  for (let i = 0; i < 50; i++) {
    let xPos = random(width);
    let yPos = random(height);
    let bubbleRadius = random(10, 50);
    bubbles.push(new Bubble(xPos, yPos, bubbleRadius));
  }
}

function draw() {
  background("#85D0F6");
  for (let bubble of bubbles) {
    bubble.update();
    bubble.show();
  }
}

class Bubble {
  constructor(xPos, yPos, bubbleRadius, growth) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.bubbleRadius = bubbleRadius;
    this.growth = 0.2;
  }

  update() {
    this.xPos += random(-2, 2);
    this.yPos += random(-2, 2);
    
    if (this.bubbleRadius < 30 || this.growth < 0) {
      this.bubbleRadius += this.growth;
      if (this.bubbleRadius >= 30 || this.bubbleRadius <= 10) {
        this.growth *= -1;
      }
    }
  }

  show() {
    push();
    stroke("white");
    fill("#D7E9F5");
    translate(this.xPos, this.yPos);
    ellipse(0, 0, this.bubbleRadius * 2);
    if (this.bubbleRadius > 32) {
      noStroke();
      fill("white");
      translate(15, -15);
      ellipse(0, 0, 10);
    }
    pop();
  }
}