let particles = [];
let breeders = [];
let catchers = [];
let breederRespawnTimer = 0;
const MAX_BREEDERS = 30;

function setup() {
  createCanvas(960, 540);
  ellipseMode(CENTER);

  for (let i = 0; i < 50; i++) {
    let xPos = random(width);
    let yPos = random(height);
    let particleRadius = random(5, 30);
    particles.push(new Particle(xPos, yPos, particleRadius));
  }

  for (let i = 0; i < 5; i++) {
    let xPos = random([5, width - 5]);
    let yPos = random(height);
    breeders.push(new Breeder(xPos, yPos));
  }

  for (let i = 0; i < 5; i++) {
    let xPos = random([5, width - 5]);
    let yPos = random(height);
    catchers.push(new Catcher(xPos, yPos));
  }
}

function draw() {
  background("#85D0F6");

  // Update particles
  for (let particle of particles) {
    particle.update();
    particle.show();
  }

  breederRespawnTimer++;
  if (breederRespawnTimer >= 750 && breeders.length < MAX_BREEDERS) {
    breeders.push(new Breeder(random([5, width - 5]), random(height), 120));
    breederRespawnTimer = 0;
  }

  for (let i = 0; i < breeders.length; i++) {
    let breederA = breeders[i];
    breederA.update();
    breederA.show();

    for (let j = i + 1; j < breeders.length; j++) {
      let breederB = breeders[j];
      let distance = dist(
        breederA.xPos,
        breederA.yPos,
        breederB.xPos,
        breederB.yPos
      );

      if (
        distance < 50 &&
        breederA.breedCooldown === 0 &&
        breederB.breedCooldown === 0 &&
        breederA.isMovingRight !== breederB.isMovingRight &&
        breeders.length < MAX_BREEDERS
      ) {
        breeders.push(new Breeder(breederA.xPos, breederA.yPos, 60));
        breederA.breedCooldown = 60;
        breederB.breedCooldown = 60;
        break;
      }
    }
  }

  for (let i = 0; i < catchers.length; i++) {
    let catcher = catchers[i];
    catcher.update();
    catcher.show();
  }
}

class Particle {
  constructor(xPos, yPos, particleRadius, growth) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.particleRadius = particleRadius;
    this.growth = 0.2;
  }

  update() {
    this.xPos += random(-2, 2);
    this.yPos += random(-2, 2);

    if (this.particleRadius < 25 || this.growth < 0) {
      this.particleRadius += this.growth;
      if (this.particleRadius >= 25 || this.particleRadius <= 5) {
        this.growth *= -1;
      }
    }
  }

  show() {
    push();
    stroke(255, 255, 255, 100);
    fill(215, 233, 245, 100);
    translate(this.xPos, this.yPos);
    ellipse(0, 0, this.particleRadius * 2);

    if (this.particleRadius > 26) {
      noStroke();
      fill(255, 255, 255, 100);
      translate(10, -12);
      ellipse(0, 0, 10);
    }
    pop();
  }
}

class Breeder {
  constructor(xPos, yPos, cooldown = 0) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.speed = random(1.5, 2.5);
    this.breedCooldown = cooldown;
    this.isMovingRight = xPos < width / 2;
  }

  update() {
    if (this.isMovingRight) {
      this.xPos += this.speed;
      if (this.xPos > width) {
        this.isMovingRight = false;
        this.xPos = width - 5;
        this.yPos = random(height);
        this.breedCooldown = 120;
      }
    } else {
      this.xPos -= this.speed;
      if (this.xPos < 0) {
        this.isMovingRight = true;
        this.xPos = 5;
        this.yPos = random(height);
        this.breedCooldown = 120;
      }
    }

    if (this.breedCooldown > 0) {
      this.breedCooldown--;
    }
  }

  show() {
    push();
    noStroke();
    fill("orange");
    ellipse(this.xPos, this.yPos, 100, 80);

    if (this.isMovingRight) {
      translate(-50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    } else {
      translate(50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(-70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    }
    pop();
  }
}

class Catcher {
  constructor(xPos, yPos) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.speed = random(1.2, 2.0);
    this.isMovingRight = xPos < width / 2;
    this.lifespan = 1000;
  }

  update() {
    if (this.isMovingRight) {
      this.xPos += this.speed;
      if (this.xPos > width) {
        this.isMovingRight = false;
        this.xPos = width - 5;
        this.yPos = random(height);
      }
    } else {
      this.xPos -= this.speed;
      if (this.xPos < 0) {
        this.isMovingRight = true;
        this.xPos = 5;
        this.yPos = random(height);
      }
    }

    this.lifespan--;
  }

  show() {
    push();
    noStroke();

    let alpha = map(this.lifespan, 0, 1000, 50, 255);
    fill(128, 0, 128, alpha);

    ellipse(this.xPos, this.yPos, 100, 70);

    if (this.isMovingRight) {
      translate(-50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill(255, alpha); // white eye with fading
      translate(70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill(0, alpha); // black pupil fading
      ellipse(this.xPos, this.yPos, 15);
    } else {
      translate(50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill(255, alpha);
      translate(-70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill(0, alpha);
      ellipse(this.xPos, this.yPos, 15);
    }

    pop();
  }
}
