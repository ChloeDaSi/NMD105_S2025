let particles = [];
let breeders = [];
let catchers = [];

function setup() {
  createCanvas(960, 540);
  ellipseMode(CENTER);

  for (let i = 0; i < 50; i++) {
    let xPos = random(width);
    let yPos = random(height);
    let particleRadius = random(5, 30);
    particles.push(new particle(xPos, yPos, particleRadius));
  }
  for (let i = 0; i < 5; i++) {
    let xPos = random([0, width]);
    let yPos = random(height);
    breeders.push(new Breeder(xPos, yPos));
  }
  for (let i = 0; i < 5; i++) {
    let xPos = random([0, width]);
    let yPos = random(height);
    catchers.push(new Catcher(xPos, yPos));
  }
}

function draw() {
  background("#85D0F6");

  for (let particle of particles) {
    particle.update();
    particle.show();
  }
  for (let breeder of breeders) {
    breeder.update();
    breeder.show();
  }
  for (let catcher of catchers) {
    catcher.update();
    catcher.show();
  }
}

class particle {
  constructor(xPos, yPos, particleRadius, growth) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.particleRadius = particleRadius;
    this.growth = 0.2;
  }

  update() {
    this.xPos += random(-2, 2);
    this.yPos += random(-2, 2);

    if (this.particleRadius < 25 || this.growth < 0) {
      this.particleRadius += this.growth;
      if (this.particleRadius >= 25 || this.particleRadius <= 5) {
        this.growth *= -1;
      }
    }
  }

  show() {
    push();
    stroke(255, 255, 255, 100);
    fill(215, 233, 245, 100);
    translate(this.xPos, this.yPos);
    ellipse(0, 0, this.particleRadius * 2);
    
    if (this.particleRadius > 26) {
      noStroke();
      fill(255, 255, 255, 100);
      translate(10, -12);
      ellipse(0, 0, 10);
    }
    pop();
  }
}

class Breeder {
  constructor(xPos, yPos) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.speed = 2;
    if (xPos === 0) {
      this.isMovingRight = true;
    }
  }

  update() {
    
  }

  show() {
    push();
    noStroke();
    fill("orange");
    ellipse(this.xPos, this.yPos, 100, 80);
    
    if (this.isMovingRight) {
      translate(-50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    }
    else {
      translate(50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(-70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    }
    pop();
  }
}

class Catcher {
  constructor(xPos, yPos) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.speed = 2;
    if (xPos === 0) {
      this.isMovingRight = true;
    }
  }

  update() {
    
  }

  show() {
    push();
    noStroke();
    fill("purple");
    ellipse(this.xPos, this.yPos, 100, 70);
    
    if (this.isMovingRight) {
      translate(-50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    }
    else {
      translate(50, 0);
      ellipse(this.xPos, this.yPos, 20, 50);
      fill("white");
      translate(-70, 0);
      ellipse(this.xPos, this.yPos, 20);
      fill("black");
      ellipse(this.xPos, this.yPos, 15);
    }
    pop();
  }
}
