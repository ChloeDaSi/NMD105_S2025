function setup() {
  createCanvas(400, 400);
  
  bubble1 = new Bubble(100, 80, 20);
  bubble2 = new Bubble(250, 120, 40);
  bubble3 = new Bubble(115, 300, 35);
  bubble4 = new Bubble(75, 200, 50);
  bubble5 = new Bubble(310, 340, 25);
}

function draw() {
  background("#85D0F6");
  bubble1.update();
  bubble1.show();
  bubble2.update();
  bubble2.show();
  bubble3.update();
  bubble3.show();
  bubble4.update();
  bubble4.show();
  bubble5.update();
  bubble5.show();
}

class Bubble {
  constructor(xPos, yPos, bubbleRadius) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.bubbleRadius = bubbleRadius;
  }

  update() {
    this.xPos += random(-2, 2);
    this.yPos += random(-2, 2);
  }

  show() {
    push();
    stroke("white");
    fill("#D7E9F5");
    translate(this.xPos, this.yPos);
    ellipse(0, 0, this.bubbleRadius * 2);
    if (this.bubbleRadius > 30) {
      noStroke();
      fill("white");
      translate(15, -15);
      ellipse(0, 0, 10);
    }
    pop();
  }
}