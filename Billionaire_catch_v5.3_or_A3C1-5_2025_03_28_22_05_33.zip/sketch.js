// Game - Billionair Catch

// Direction - Quickly catch the musky man before he takes away your grandmothers money. Right click your mouse or touchpad to drop musky man from the sky. Right click your mouse or touchpad again to open the trashcans lid and capture him inside to keep your grandmother from starving.

// Enjoy!!!

let muskyManX;
let muskyManY = 0;
let falling = false;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background("skyblue");

  // Ground
  push();
  noStroke();
  fill("darkgreen");
  rect(0, 325, 400, 75);
  pop();

  let detectionX = mouseX;
  let detectionY = 250;

  // Checks for collision of Lid and muskyMan
  let lidOpen =
    falling && muskyManX > detectionX - 45 && muskyManX < detectionX + 45;

  trashCan(detectionX, detectionY, lidOpen || mouseIsPressed);

  if (falling) {
    muskyMan(muskyManX, muskyManY);
    muskyManY += muskyManSpeed;

    // Checks if muskyMan has hit ground or trash can
    if (muskyManY > height) {
      muskyManY = 0;
      falling = false;
    } else if (
      lidOpen &&
      muskyManY + 18 > detectionY &&
      muskyManY - 18 < detectionY
    ) {
      falling = false; 
    }
  }
}

function trashCan(x, y, lidOpen) {
  push();
  translate(x, y);

  // Trash can
  fill("grey");
  quad(10, 28, 70, 28, 65, 108, 20, 108);

  // Lid
  if (lidOpen) {
    rotate(-90);
    translate(-15, -25);
    rect(5, 20, 70, 8);
    // Handle
    rect(30, 15, 20, 6);
  } else {
    rect(5, 20, 70, 8);
    // Handle
    rect(30, 15, 20, 6);
  }
  pop();
}

function muskyMan(x, y) {
  push();
  translate(x, y);

  // muskyMan
  fill("tan");
  ellipse(0, 0, 30, 36);
  // Eyes
  fill("lightgreen");
  ellipse(-5, -2, 2);
  ellipse(5, -2, 2);
  // Hat
  fill("black");
  arc(0, -5, 26, 30, 190, 345);
  // Hat logo
  push();
  stroke("white");
  line(-2, -15, 2, -15);
  line(0, -15, 0, -10);
  pop();
  fill("white");
  arc(0, 10, 15, 5, 210, 330, PIE);

  pop();
}

function mousePressed() {
  if (!falling) {
    muskyManX = random(400);
    muskyManY = 0;
    muskyManSpeed = random(1.5, 4);
    falling = true;
  }
}
