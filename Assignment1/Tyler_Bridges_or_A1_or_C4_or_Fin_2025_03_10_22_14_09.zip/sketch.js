let hue = 80;

function sky() {
  if (mouseX >= 200) {
    background("purple");
  } else if (mouseX <= 200) {
    background("hotpink");
  }
}

function setup() {
  createCanvas(400, 400);
}
sky();

function draw() {
  sky();

  let xPos = 40;
  let yPos = 40;
  let size = 80;

  //Initial
  fill(`hsla( ${276 + hue}, 100%, 20%, 1)`);

  //Top row
  ellipse(xPos, yPos, size);
  ellipse(xPos + 80, yPos, size);
  ellipse(xPos + 160, yPos, size);
  ellipse(xPos + 240, yPos, size);
  ellipse(xPos + 320, yPos, size);

  //Stem
  fill(`hsla( ${276 + hue}, 67%, 28%, 1)`);
  ellipse(xPos + 160, yPos + 80, size);

  fill(`hsla( ${276 + hue}, 56%, 36%, 1)`);
  ellipse(xPos + 160, yPos + 160, size);

  fill(`hsla( ${276 + hue}, 49%, 44%, 1)`);
  ellipse(xPos + 160, yPos + 240, size);
  fill(`hsla( ${276 + hue}, 42%, 56%, 1)`);

  ellipse(xPos + 160, yPos + 320, size);

  //Background
  //Row 1
  fill(`hsla( ${194 + hue}, 100%, 29%, 1)`);

  ellipse(xPos, yPos + 80, size);
  ellipse(xPos + 80, yPos + 80, size);
  ellipse(xPos + 240, yPos + 80, size);
  ellipse(xPos+ 320, yPos + 80, size);

  //Row 2
  fill(`hsla( ${200 + hue}, 100%, 27%, 1)`);

  ellipse(xPos, yPos + 160, size);
  ellipse(xPos + 80, yPos + 160, size);
  ellipse(xPos + 240, yPos + 160, size);
  ellipse(xPos + 320, yPos + 160, size);

  //Row 3
  fill(`hsla( ${212 + hue}, 58%, 28%, 1)`);

  ellipse(xPos, yPos + 240, size);
  ellipse(xPos + 80, yPos + 240, size);
  ellipse(xPos + 240, yPos + 240, size);
  ellipse(xPos + 320, yPos + 240, size);

  //Row 4
  fill(`hsla( ${232 + hue}, 35%, 24%, 1)`);

  ellipse(xPos + 80, yPos + 320, size);
  ellipse(xPos, yPos + 320, size);
  ellipse(xPos + 240, yPos + 320, size);
  ellipse(xPos + 320, yPos + 320, size);
}
